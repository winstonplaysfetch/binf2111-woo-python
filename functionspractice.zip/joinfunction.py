#! /usr/bin/env python

#inputDNA = raw_input("Enter file name: ")
inputDNA = "multiline-adapt.fna"

def single_fasta(DNAfile):
    sequences = {}
    with open(DNAfile) as infile:
        for line in infile:
            line = line.rstrip()
            if line.startswith(">"):
                header = line
                sequences[header] =''
            else:
                sequences[header] += line
    return sequences

joinseq = single_fasta(inputDNA)
for key, value in joinseq.items():
    print key + "\n" + value
